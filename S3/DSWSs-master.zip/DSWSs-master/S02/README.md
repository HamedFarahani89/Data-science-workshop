# DSWSs-Session02 repository

You can fnid the course program and the videos [HERE](http://physics.ipm.ac.ir/~vafaei/scheduls/sess2.html)
