#!/home/gf/packages/anaconda3/bin/python

from numpy.random import randint as rand

x = rand(1,7, size=1)

print(x[0])
