# DSWSs-Session03 repository

You can fnid the course program and the videos [HERE](http://physics.ipm.ac.ir/~vafaei/scheduls/sess3.html)


- [jupyter_notebooks](https://github.com/vafaei-ar/DSWSs/blob/master/S03/notebooks/jupyter_notebooks.ipynb) [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/vafaei-ar/DSWSs/blob/master/S03/notebooks/jupyter_notebooks.ipynb)

- [numpy-II](https://github.com/vafaei-ar/DSWSs/blob/master/S03/notebooks/numpy-ii.ipynb) [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/vafaei-ar/DSWSs/blob/master/S03/notebooks/numpy-ii.ipynb)

- [pandas-intro](https://github.com/vafaei-ar/DSWSs/blob/master/S03/notebooks/pandas-intro.ipynb) [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/vafaei-ar/DSWSs/blob/master/S03/notebooks/pandas-intro.ipynb)

- [pandas-practice](https://github.com/vafaei-ar/DSWSs/blob/master/S03/notebooks/pandas_practice.ipynb) [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/vafaei-ar/DSWSs/blob/master/S03/notebooks/pandas_practice.ipynb)
