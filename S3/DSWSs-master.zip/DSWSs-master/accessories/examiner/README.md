# Examiner

This script is the one who checks your exercises.
It's one of the lovelies!
